<?php
// Heading
$_['heading_title']    = 'Người trực tuyến';

// Text
$_['text_extension']   = 'Tiện ích mở rộng';
$_['text_success']     = 'Thành công: Bạn đã sửa đổi bảng điều khiển trực tuyến!';
$_['text_edit']        = 'Chỉnh sửa Bảng điều khiển Trực tuyến';
$_['text_view']        = 'Xem nhiều hơn...';

// Entry
$_['entry_status']     = 'Tình trạng';
$_['entry_sort_order'] = 'Thứ tự';
$_['entry_width']      = 'Ngang';

// Error
$_['error_permission'] = 'Cảnh báo: Bạn không có quyền sửa đổi bảng điều khiển trực tuyến!';