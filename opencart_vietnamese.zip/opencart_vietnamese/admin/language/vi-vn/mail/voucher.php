<?php
// Text
$_['text_success']  = 'Thành công: Bạn đã sửa đổi voucher!';
$_['text_subject']  = 'Bạn đã được gửi một phiếu voucher từ %s';
$_['text_greeting'] = 'Xin chúc mừng , bạn đã nhận được phiếu voucher giá trị %s';
$_['text_from']     = 'Thẻ voucher đã được gửi đến cho bạn từ %s';
$_['text_message']  = 'Có thông điệp';
$_['text_redeem']   = 'Để mua lại giấy voucher , ghi mã <b>%s</b> sau đó nhấn vào liên kết bên dưới và mua sản phẩm bạn muốn sử dụng phiếu voucher. Bạn có thể nhập mã phiếu voucher trên trang giỏ mua hàng trước khi bạn nhấp vào kiểm.';
$_['text_footer']   = 'Xin vui lòng trả lời email này nếu bạn có bất kỳ câu hỏi nào.';