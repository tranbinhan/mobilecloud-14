<?php
// Text
$_['text_subject']  = '%s - Điểm thưởng';
$_['text_received'] = 'Bạn đã nhận được %s Điểm thưởng!';
$_['text_total']    = 'Tổng số điểm thưởng của bạn bây giờ làs %s.';