<?php
// Heading
$_['heading_title']    = 'Tổng đơn hàng';

// Text
$_['text_extension']   = 'Tiện ích mở rộng';
$_['text_success']     = 'Thành công: Bạn đã sửa đổi các đơn đặt hàng trang tổng quan!';
$_['text_edit']        = 'Chỉnh sửa Bảng điều khiển Đơn đặt hàng';
$_['text_view']        = 'Xem nhiều hơn...';

// Entry
$_['entry_status']     = 'Tình trạng';
$_['entry_sort_order'] = 'Thứ tự';
$_['entry_width']      = 'Ngang';

// Error
$_['error_permission'] = 'Cảnh báo: Bạn không có quyền sửa đổi đơn đặt hàng trang tổng quan!';