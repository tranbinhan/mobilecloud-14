<?php
// Heading
$_['heading_title']     = 'Quản lý Tập tin';

// Text
$_['text_success']      = 'Chúc mừng! Bạn đã cập nhật thành công!';
$_['text_list']         = 'Danh mục Tập tin';

// Column
$_['column_name']       = 'Tên Upload';
$_['column_filename']   = 'Tên Tập tin';
$_['column_date_added'] = 'Ngày đăng';
$_['column_action']     = 'Thao tác';

// Entry
$_['entry_name']        = 'Tên Upload';
$_['entry_filename']    = 'Tên Tập tin';
$_['entry_date_added'] 	= 'Ngày thêm';

// Error
$_['error_permission']  = 'Chú ý: Bạn không có quyền chỉnh sửa mục này!';