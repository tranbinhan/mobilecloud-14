<?php
// Text
$_['text_success']     = 'Thành công: Bạn thay đổi loại tiền thành công!';

// Error
$_['error_permission'] = 'Cảnh báo: Bạn không có thẩm quyền truy cập API!';
$_['error_currency']   = 'Cảnh báo: Mã tiền tệ không hợp lệ!';