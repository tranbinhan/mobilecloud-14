<?php
// Text
$_['text_success']       = 'Bạn đã sửa đổi thành công khách hàng';

// Error
$_['error_permission']   = 'Cảnh báo: Bạn không có quyền truy cập vào API!';
$_['error_customer']     = 'Bạn phải chọn một khách hàng!';
$_['error_firstname']    = 'Tên phải từ 1 đến 32 ký tự!';
$_['error_lastname']     = 'Họ phải có từ 1 đến 32 ký tự!';
$_['error_email']        = 'Địa chỉ E-Mail có vẻ không hợp lệ!';
$_['error_telephone']    = 'Điện thoại phải có từ 3 đến 32 ký tự!';
$_['error_custom_field'] = '%s yêu cầu!';