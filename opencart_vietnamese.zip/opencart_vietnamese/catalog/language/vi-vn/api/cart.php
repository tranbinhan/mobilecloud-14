<?php
// Text
$_['text_success']     = 'Chúc Mừng! Bạn đã cập nhật Thành công!';

// Error
$_['error_permission'] = 'Cảnh báo! Bạn không có quyền truy cập API!';
$_['error_stock']      = 'Sản phẩm có dấu *** hiện hết hàng!';
$_['error_minimum']    = 'Yêu cầu đặt hàng tối thiểu cho sản phẩm %s là %s!';
$_['error_store']      = 'Bạn không thể đặt hàng từ Nhà cung cấp này!';
$_['error_required']   = '%s Yêu cầu!';