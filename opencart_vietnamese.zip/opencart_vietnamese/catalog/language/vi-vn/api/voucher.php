<?php
// Text
$_['text_success']     = 'Thành công: Chiết khấu phiếu giảm giá quà tặng của bạn đã được áp dụng!';
$_['text_cart']        = 'Thành công: Bạn đã sửa đổi giỏ hàng!';
$_['text_for']         = '%s Giấy chứng nhận quà tặng cho %s';

// Error
$_['error_permission'] = 'Cảnh báo: Bạn không có quyền truy cập vào API!';
$_['error_voucher']    = 'Cảnh báo: Phiếu quà tặng hoặc không hợp lệ hoặc số dư đã được sử dụng hết!';
$_['error_to_name']    = 'Tên người nhận phải từ 1 đến 64 ký tự!';
$_['error_from_name']  = 'Tên của bạn phải từ 1 đến 64 ký tự!';
$_['error_email']      = 'Địa chỉ E-Mail có vẻ không hợp lệ!';
$_['error_theme']      = 'Bạn phải chọn một giao diện!';
$_['error_amount']     = 'Số tiền phải nằm trong khoảng %s và %s!';