<?php
// Heading
$_['heading_title'] = 'Thông tin';

// Text
$_['text_contact']  = 'Liên hệ với chúng tôi';
$_['text_sitemap']  = 'Sơ đồ trang';