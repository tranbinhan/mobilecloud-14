<?php
// Heading
$_['heading_title'] = 'Chọn một gian hàng';

// Text
$_['text_default']  = 'Mặc định';
$_['text_store']    = 'Vui lòng chọn các cửa hàng bạn muốn truy cập.';