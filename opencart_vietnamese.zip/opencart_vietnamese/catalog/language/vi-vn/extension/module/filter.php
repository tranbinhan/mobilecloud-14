<?php
// Heading
$_['heading_title'] = 'Tinh chỉnh tìm kiếm';