<?php
// Text
$_['text_title']          = 'PayPal Express Checkout';
$_['text_canceled']       = 'Thành công: Bạn đã hủy thành công việc thanh toán này!';

// Button
$_['button_cancel']       = 'Cancel Recurring Payment';

// Error
$_['error_not_cancelled'] = 'Lỗi: %s';
$_['error_not_found']     = 'Could not cancel recurring profile';